# AI model for phishing
this is a model which detect phishing url or phishing pdf or file 

link for video
https://github.com/user-attachments/assets/ebe2aee4-33db-4592-8791-fedcdbf889be

